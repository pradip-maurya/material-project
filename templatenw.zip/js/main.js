// for slimScroll 
$(document).ready(function(){

	$('.slimscroll-class').slimScroll({
		position: 'right',
		height: '430',
		alwaysVisible: false
	});
});
// for slimScroll End